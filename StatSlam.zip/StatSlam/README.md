# StatSlam
 StatSlam is an interactive analytics platform for viewing statistics of NBA teams and players\
 StatSlam is written using PHP, HTML, and CSS and is developed using the XAMPP stack
